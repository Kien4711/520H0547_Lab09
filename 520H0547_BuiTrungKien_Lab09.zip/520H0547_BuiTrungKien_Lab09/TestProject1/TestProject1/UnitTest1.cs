using StudentServiceLib;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        private Student student;
        [TestInitialize]
        public void init()
        {
            student = new Student();
        }
        [TestMethod]
        public void WhenScoreBiggerThan10_ResultFalse()
        {
            double sc = 11;
            Boolean result = true;
            try
            {
                student.Score = sc;
            }
            catch (SystemException)
            {
                result = false;
            }
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void WhenScoreFrom0to10_ResultTrue()
        {
            double sc = 7;
            Boolean result = true;
            try
            {
                student.Score = sc;
            }
            catch (SystemException)
            {
                result = false;
            }
            Assert.IsTrue(result);
        }
        [TestMethod]
        public void WhenScoreSamllerThan0_ResultFalse()
        {
            double sc = -1;
            Boolean result = true;
            try
            {
                student.Score = sc;
            }
            catch (SystemException)
            {
                result = false;
            }
            Assert.IsFalse(result, "Score need >= 0");
        }

        [TestMethod]
        public void checkLetterScoreequal7()
        {
            
            double sc = 7;
            student.Score = sc;
            char letter = student.getLetterScore();

            Assert.AreEqual('B', letter);
        }
        [TestMethod]
        public void checkLetterScoreequal5()
        {

            double sc = 5;
            student.Score = sc;
            char letter = student.getLetterScore();

            Assert.AreEqual('C', letter);
        }
        [TestMethod]
        public void checkLetterScorefrom4to5()
        {

            double sc = 4.5;
            student.Score = sc;
            char letter = student.getLetterScore();

            Assert.AreEqual('D', letter);
        }
        [TestMethod]
        public void checkLetterScorefrom8to10()
        {

            double sc = 9;
            student.Score = sc;
            char letter = student.getLetterScore();

            Assert.AreEqual('A', letter);
        }
        [TestMethod]
        public void checkMSSV()
        {
            StudentService stS = new StudentService();
            Student st1 = new Student();
            st1.Id = 1;
            Student st2 = new Student();
            st1.Id = 1;
            stS.addStudent(st1);
            Boolean isFalse = false;
            if (stS.addStudent(st2))
            {
                isFalse = true;
            }
            Assert.IsTrue(isFalse);
        }
    }
}